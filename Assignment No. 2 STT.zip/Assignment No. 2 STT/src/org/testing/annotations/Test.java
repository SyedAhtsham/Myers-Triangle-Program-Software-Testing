package org.testing.annotations;

public @interface Test {

	String dataProvider();

}
