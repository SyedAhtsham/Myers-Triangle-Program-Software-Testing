package com.triangle.util;

public enum Type {
	SCALENE, ISOSCELES, EQUILATERAL, BADSIDE, NOTRIANGLE

}
